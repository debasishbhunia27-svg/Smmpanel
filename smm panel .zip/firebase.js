// FIREBASE CONFIGURATION & INITIALIZATION
const firebaseConfig = {
  apiKey: "AIzaSyAxrKg7img5u7G_mCeV1nlffF4Do9lTqBE",
  authDomain: "smm-panel-website-1ee26.firebaseapp.com",
  databaseURL: "https://smm-panel-website-1ee26-default-rtdb.firebaseio.com",
  projectId: "smm-panel-website-1ee26",
  storageBucket: "smm-panel-website-1ee26.firebasestorage.app",
  messagingSenderId: "755961604209",
  appId: "1:755961604209:web:c67f0b1cfcd05fead8d3d0",
  measurementId: "G-Y7DQW5F0GM"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Export Auth & DB globally
const auth = firebase.auth();
const db = firebase.database();

// ImgBB API Key (Global)
const IMGBB_KEY = "172dabb7ec93ead71d6b9e5631f3155d";

console.log("Firebase Connected via firebase.js");